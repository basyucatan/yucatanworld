document.addEventListener('DOMContentLoaded', function() {

    const currentLang = localStorage.getItem('preferredLang') || 'es';
    const htmlEl = document.documentElement;

    // Diccionario de textos para title y meta description
    const pageTexts = {
        es: {
            title: "Vive en Mérida, Yucatán - Tu Paraíso Seguro",
            description: "Descubre Mérida, la ciudad más segura de México. Un lugar lleno de historia, belleza natural y oportunidades inmobiliarias únicas."
        },
        en: {
            title: "Live in Merida, Yucatan - Your Safe Paradise",
            description: "Discover Merida, the safest city in Mexico. A place full of history, natural beauty, and unique real estate opportunities."
        }
    };

    // --- Mobile Navigation Toggle ---
    const mobileNavToggle = document.querySelector('.mobile-nav-toggle');
    const mobileNavPanel = document.querySelector('.mobile-nav-panel');
    const mobileNavLinks = mobileNavPanel.querySelectorAll('a');

    if (mobileNavToggle && mobileNavPanel) {
        mobileNavToggle.addEventListener('click', () => {
            const isExpanded = mobileNavToggle.getAttribute('aria-expanded') === 'true' || false;
            mobileNavToggle.setAttribute('aria-expanded', !isExpanded);
            mobileNavPanel.classList.toggle('open');
            // Cambiar icono hamburguesa a X y viceversa
            const icon = mobileNavToggle.querySelector('i');
            if (mobileNavPanel.classList.contains('open')) {
                icon.classList.remove('fa-bars');
                icon.classList.add('fa-times');
                document.body.style.overflow = 'hidden'; // Evitar scroll del body cuando el menú está abierto
            } else {
                icon.classList.remove('fa-times');
                icon.classList.add('fa-bars');
                document.body.style.overflow = '';
            }
        });

        // Cerrar menú móvil al hacer clic en un enlace
        mobileNavLinks.forEach(link => {
            link.addEventListener('click', () => {
                if (mobileNavPanel.classList.contains('open')) {
                    mobileNavToggle.click(); // Simula clic para cerrar
                }
            });
        });
    }


    // --- Language Switcher ---
    const langButtons = document.querySelectorAll('.lang-btn');
    const allLangEsElements = document.querySelectorAll('.lang-es');
    const allLangEnElements = document.querySelectorAll('.lang-en');
    const pageTitleEl = document.getElementById('pageTitle');
    const pageDescriptionEl = document.getElementById('pageDescription');

    function setLanguage(lang) {
        htmlEl.setAttribute('lang', lang); // Actualizar el lang del tag <html>

        if (lang === 'es') {
            allLangEsElements.forEach(el => el.style.display = 'inline'); // o 'block' o 'flex' según el elemento
            allLangEnElements.forEach(el => el.style.display = 'none');
            pageTitleEl.textContent = pageTexts.es.title;
            pageDescriptionEl.setAttribute('content', pageTexts.es.description);
        } else {
            allLangEsElements.forEach(el => el.style.display = 'none');
            allLangEnElements.forEach(el => el.style.display = 'inline'); // o 'block' o 'flex'
            pageTitleEl.textContent = pageTexts.en.title;
            pageDescriptionEl.setAttribute('content', pageTexts.en.description);
        }

        // Actualizar botón activo
        langButtons.forEach(btn => {
            btn.classList.toggle('active', btn.dataset.lang === lang);
        });

        localStorage.setItem('preferredLang', lang); // Guardar preferencia
    }

    langButtons.forEach(button => {
        button.addEventListener('click', () => {
            setLanguage(button.dataset.lang);
        });
    });

    // Aplicar idioma guardado o por defecto al cargar
    setLanguage(currentLang);


    // --- Smooth scroll para enlaces de anclaje (navegación desktop y móvil) ---
    const anchorLinks = document.querySelectorAll('a[href^="#"]');
    anchorLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            let targetId = this.getAttribute('href');
            let targetElement = document.querySelector(targetId);

            if (targetElement) {
                let headerOffset = 0;
                const nav = document.querySelector('.navegacion');
                // Si la navegación es fija (tiene clase 'nav-scrolled' o siempre es fija)
                if (nav && (nav.classList.contains('nav-scrolled') || getComputedStyle(nav).position === 'fixed')) {
                    headerOffset = nav.offsetHeight;
                }

                let elementPosition = targetElement.getBoundingClientRect().top;
                let offsetPosition = elementPosition + window.pageYOffset - headerOffset;

                window.scrollTo({
                     top: offsetPosition,
                     behavior: "smooth"
                });
            }
        });
    });


    // --- Sticky Navigation (cambiar clase al hacer scroll) ---
    const navegacion = document.querySelector('.navegacion');
    const heroSection = document.querySelector('.hero'); // Para determinar cuándo hacer sticky

    if (navegacion && heroSection) {
        // Considerar la altura original de la navegación para el punto de activación
        const navOriginalHeight = navegacion.offsetHeight;
        window.addEventListener('scroll', function() {
            // Activar cuando el scroll es mayor que la altura del hero menos la altura de la nav
            // O una altura fija si el hero no es full-height
            let stickyPoint = (heroSection.offsetHeight > window.innerHeight) ? (heroSection.offsetHeight - navOriginalHeight) : (window.innerHeight - navOriginalHeight - 50);
            if (stickyPoint < navOriginalHeight) stickyPoint = navOriginalHeight; // Evitar que sea muy pronto

            if (window.scrollY > stickyPoint) {
                if (window.scrollY > navOriginalHeight) { // Solo añade si ya pasaste la altura original de la nav
                   navegacion.classList.add('nav-scrolled');
                }
            } else {
                navegacion.classList.remove('nav-scrolled');
            }
        });
    }


    // --- Animaciones al hacer scroll con Intersection Observer (AOS o similar es recomendado para más control) ---
    const seccionesAnimadas = document.querySelectorAll('.seccion h2, .seccion .columna-texto, .seccion .columna-imagen, .tarjeta-propiedad, .formulario-contacto');
    const observerOptions = { root: null, rootMargin: '0px', threshold: 0.1 };

    const observerCallback = (entries, observer) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.opacity = '1'; // Ejemplo simple de animación
                entry.target.style.transform = 'translateY(0)';
                observer.unobserve(entry.target);
            }
        });
    };
    const observer = new IntersectionObserver(observerCallback, observerOptions);
    seccionesAnimadas.forEach(el => {
        el.style.opacity = '0'; // Estilo inicial para la animación
        el.style.transform = 'translateY(30px)';
        el.style.transition = 'opacity 0.8s ease-out, transform 0.8s ease-out';
        observer.observe(el);
    });

    // --- Inicializar AOS si se usa (descomentar en HTML y aquí) ---
    // if (typeof AOS !== 'undefined') {
    //     AOS.init({
    //         duration: 1000,
    //         once: true,
    //         offset: 100,
    //     });
    // }

    console.log("Página de Mérida Inmobiliaria (v2) cargada y lista.");
});