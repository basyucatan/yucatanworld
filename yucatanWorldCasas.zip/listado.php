<?php
// Datos de conexión a la base de datos
$servername = "localhost";
$username = "webselfe_bas";
$password = "Dumbos2405$";
$dbname = "webselfe_contactos";

// Crear conexión
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

// Acción de borrar mensajes largos
if (isset($_POST['borrar_largos'])) {
    $delete_sql = "DELETE FROM contactos WHERE CHAR_LENGTH(mensaje) > 200";
    $conn->query($delete_sql);
    echo "<script>alert('Mensajes largos eliminados'); window.location.href='listado.php';</script>";
    exit;
}

// Consulta para obtener los datos ordenados
$sql = "SELECT sistema, fecha, nombre, mensaje 
        FROM contactos 
        ORDER BY fecha DESC, sistema ASC, nombre ASC";

$result = $conn->query($sql);

// Función para truncar mensaje a ~20 palabras
function resumenMensaje($mensaje, $maxPalabras = 20) {
    $palabras = preg_split('/\s+/', $mensaje);
    if(count($palabras) > $maxPalabras) {
        return implode(' ', array_slice($palabras, 0, $maxPalabras)) . '...';
    }
    return $mensaje;
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Contactos</title>
    <style>
        body { font-family: Arial, sans-serif; padding: 20px; background: #f4f4f4; }
        table { border-collapse: collapse; width: 100%; background: #fff; }
        th, td { border: 1px solid #ccc; padding: 10px; text-align: left; }
        th { background: #eee; }
        tr:nth-child(even) { background: #f9f9f9; }
        form { margin-bottom: 20px; }
        button { padding: 8px 12px; cursor: pointer; }
    </style>
</head>
<body>
    <h3>Administración de Contactos</h3>

    <!-- Formulario para borrar mensajes largos -->
    <form method="POST" onsubmit="return confirm('¿Seguro que quieres borrar todos los mensajes con más de 100 caracteres?');">
        <button type="submit" name="borrar_largos">Borrar mensajes largos</button>
    </form>

    <table>
        <thead>
            <tr>
                <th>Sistema</th>
                <th>Fecha</th>
                <th>Nombre</th>
                <th>Mensaje</th>
            </tr>
        </thead>
        <tbody>
            <?php
            if ($result && $result->num_rows > 0) {
                while($row = $result->fetch_assoc()) {
                    echo "<tr>";
                    echo "<td>" . htmlspecialchars($row['sistema']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['fecha']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['nombre']) . "</td>";
                    echo "<td>" . nl2br(htmlspecialchars(resumenMensaje($row['mensaje']))) . "</td>";
                    echo "</tr>";
                }
            } else {
                echo "<tr><td colspan='4'>No hay registros.</td></tr>";
            }
            ?>
        </tbody>
    </table>
</body>
</html>

<?php
$conn->close();
?>
