<?php
// Datos de conexión a la base de datos
$servername = "localhost";
$username = "webselfe_bas";
$password = "Dumbos2405$";
$dbname = "webselfe_contactos";

// Crear conexión
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar la conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

// Validar existencia de los datos POST
if (
    isset($_POST['name']) && isset($_POST['email']) &&
    isset($_POST['telefono']) && isset($_POST['message'])
) {
    // Limpiar entradas
    $nombre = trim($_POST['name']);
    $email = trim($_POST['email']);
    $telefono = trim($_POST['telefono']);
    $mensaje = trim($_POST['message']);
    $sistema = 'YucatanWorld';

    // Validación básica de campos requeridos
    if (empty($nombre) || empty($email) || empty($mensaje)) {
        echo "<script>alert('Por favor completa todos los campos requeridos.'); window.history.back();</script>";
        exit;
    }

    // Preparar y ejecutar la consulta
    $sql = "INSERT INTO contactos (nombre, email, telefono, sistema, mensaje) VALUES (?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);

    if ($stmt) {
        $stmt->bind_param("sssss", $nombre, $email, $telefono, $sistema, $mensaje);
        if ($stmt->execute()) {
            echo "<script>alert('¡Gracias! Su mensaje ha sido enviado con éxito.'); window.location.href='index.php';</script>";
        } else {
            echo "<script>alert('Error al guardar el mensaje.'); window.history.back();</script>";
        }
        $stmt->close();
    } else {
        echo "<script>alert('Error en la preparación de la consulta.'); window.history.back();</script>";
    }
} else {
    echo "<script>alert('Formulario incompleto.'); window.history.back();</script>";
}

$conn->close();
?>
