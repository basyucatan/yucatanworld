<!DOCTYPE html>
<html lang="es"> <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title id="pageTitle">Vive en Mérida |Tu Paraíso Seguro</title>
    <meta name="description" id="pageDescription" content="Descubre Mérida, la ciudad más segura de México. Un lugar lleno de historia, belleza natural y oportunidades inmobiliarias únicas.">

    <link rel="stylesheet" href="estilos.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700&family=Roboto:wght@300;400;700&display=swap" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet"> </head>
<body>

    <header class="hero">
        <div class="hero-overlay">
            <div class="contenedor">
                <nav class="navegacion">
                    <a href="#seguridad" class="logo">
                        <span class="lang-es">Yucatán World</span>
                        <span class="lang-en">Yucatán World</span>
                    </a>
                    <ul class="nav-desktop">
                        <li><a href="#seguridad"><span class="lang-es">Seguridad</span><span class="lang-en">Safety</span></a></li>
                        <li><a href="#naturaleza"><span class="lang-es">Naturaleza</span><span class="lang-en">Nature</span></a></li>
                        <li><a href="#historia"><span class="lang-es">Historia</span><span class="lang-en">History</span></a></li>
                        <li><a href="#propiedades"><span class="lang-es">Propiedades</span><span class="lang-en">Properties</span></a></li>
                        <li><a href="#contacto"><span class="lang-es">Contacto</span><span class="lang-en">Contact</span></a></li>
                    </ul>
                    <div class="nav-controls">
<div class="language-switcher">
    <button data-lang="es" class="lang-btn active">
        <img src="img/es.png" alt="Español" width="24" height="16">
    </button>
    <button data-lang="en" class="lang-btn">
        <img src="img/en.png" alt="English" width="24" height="16">
    </button>
</div>

                        <button class="mobile-nav-toggle" aria-label="Toggle navigation" aria-expanded="false">
                            <i class="fas fa-bars"></i> </button>
                    </div>
                </nav>
                <div class="mobile-nav-panel">
                    <ul>
                        <li><a href="#seguridad"><span class="lang-es">Seguridad</span><span class="lang-en">Safety</span></a></li>
                        <li><a href="#naturaleza"><span class="lang-es">Naturaleza</span><span class="lang-en">Nature</span></a></li>
                        <li><a href="#historia"><span class="lang-es">Historia</span><span class="lang-en">History</span></a></li>
                        <li><a href="#propiedades"><span class="lang-es">Propiedades</span><span class="lang-en">Properties</span></a></li>
                        <li><a href="#contacto"><span class="lang-es">Contacto</span><span class="lang-en">Contact</span></a></li>
                    </ul>
                </div>

                <div class="hero-content">
                    <h1>
                        <span class="lang-es">Descubre Mérida: Tu Hogar en el Corazón de Yucatán</span>
                        <span class="lang-en">Discover Merida: Your Home in the Heart of Yucatan</span>
                    </h1>
                    <p class="subtitulo">
                        <span class="lang-es">La ciudad más segura de México te espera con los brazos abiertos. Invierte en tu futuro, invierte en calidad de vida.</span>
                        <span class="lang-en">The safest city in Mexico awaits you with open arms. Invest in your future, invest in quality of life.</span>
                    </p>
                </div>
            </div>
        </div>
    </header>

    <main>
        <section id="seguridad" class="seccion">
            <div class="contenedor">
                <h2 data-aos="fade-up">
                    <span class="lang-es">Mérida: Un Oasis de Paz y Seguridad</span>
                    <span class="lang-en">Merida: An Oasis of Peace and Safety</span>
                </h2>
                <div class="grid-dos-columnas">
                    <div class="columna-texto" data-aos="fade-right">
                        <p>
                            <span class="lang-es">En Mérida, la tranquilidad es más que una promesa, es una realidad palpable. Reconocida consistentemente como la ciudad más segura de México y una de las más seguras de Latinoamérica, te ofrece un entorno donde tú y tu familia pueden prosperar sin preocupaciones.</span>
                            <span class="lang-en">In Merida, tranquility is more than a promise; it's a palpable reality. Consistently recognized as the safest city in Mexico and one of the safest in Latin America, it offers an environment where you and your family can thrive without worry.</span>
                        </p>
                        <p>
                            <span class="lang-es">Disfruta de calles vibrantes, parques llenos de vida y una comunidad acogedora que valora la armonía y el respeto. Aquí, la calidad de vida se eleva, permitiéndote enfocarte en lo que realmente importa.</span>
                            <span class="lang-en">Enjoy vibrant streets, lively parks, and a welcoming community that values harmony and respect. Here, the quality of life is elevated, allowing you to focus on what truly matters.</span>
                        </p>
                    </div>
                    <div class="columna-imagen" data-aos="fade-left">
                        <img src="img/banner01.jpg" alt="Paseo de Montejo, Merida - Symbol of Safety">
                    </div>
                </div>
            </div>
        </section>

        <section id="naturaleza" class="seccion bg-alterno">
            <div class="contenedor">
                <h2 data-aos="fade-up">
                    <span class="lang-es">Belleza Natural que Cautiva</span>
                    <span class="lang-en">Captivating Natural Beauty</span>
                </h2>
                <div class="grid-dos-columnas inversa">
                    <div class="columna-imagen" data-aos="fade-right">
                        <img src="img/cenote01.jpg" alt="Crystalline Cenote near Merida">
                    </div>
                    <div class="columna-texto" data-aos="fade-left">
                        <p>
                            <span class="lang-es">Yucatán es un tesoro de maravillas naturales, y Mérida es la puerta de entrada a este paraíso. Explora cenotes místicos de aguas cristalinas, antiguas cuevas que narran historias milenarias y reservas ecológicas que albergan una biodiversidad asombrosa.</span>
                            <span class="lang-en">Yucatan is a treasure trove of natural wonders, and Merida is the gateway to this paradise. Explore mystical cenotes with crystal-clear waters, ancient caves that tell age-old stories, and ecological reserves harboring astonishing biodiversity.</span>
                        </p>
                        <p>
                            <span class="lang-es">Desde las playas de arena blanca de la Costa Esmeralda hasta la exuberante selva maya, la naturaleza te invita a la aventura y al descanso, ofreciendo un escape perfecto de la rutina diaria.</span>
                            <span class="lang-en">From the white sandy beaches of the Emerald Coast to the lush Mayan jungle, nature invites you to adventure and relaxation, offering a perfect escape from daily routine.</span>
                        </p>
                    </div>
                </div>
            </div>
        </section>

        <section id="historia" class="seccion">
            <div class="contenedor">
                <h2 data-aos="fade-up">
                    <span class="lang-es">Un Legado Histórico que Perdura</span>
                    <span class="lang-en">An Enduring Historical Legacy</span>
                </h2>
                <div class="grid-dos-columnas">
                    <div class="columna-texto" data-aos="fade-right">
                        <p>
                            <span class="lang-es">Mérida es una ciudad donde el pasado y el presente convergen de manera majestuosa. Fundada sobre la antigua ciudad maya de T'Hó, su arquitectura colonial, calles empedradas y majestuosas haciendas henequeneras cuentan la historia de un rico legado cultural.</span>
                            <span class="lang-en">Merida is a city where past and present majestically converge. Founded on the ancient Mayan city of T'Hó, its colonial architecture, cobblestone streets, and majestic henequen haciendas tell the story of a rich cultural legacy.</span>
                        </p>
                        <p>
                            <span class="lang-es">Visita imponentes zonas arqueológicas mayas como Chichén Itzá y Uxmal, maravíllate con los museos de clase mundial y sumérgete en las tradiciones vivas que hacen de Mérida un crisol cultural único en el mundo.</span>
                            <span class="lang-en">Visit imposing Mayan archaeological sites like Chichen Itza and Uxmal, marvel at world-class museums, and immerse yourself in the living traditions that make Merida a unique cultural melting pot in the world.</span>
                        </p>
                    </div>
                    <div class="columna-imagen" data-aos="fade-left">
                        <img src="img/centroh01.jpg" alt="Cathedral of Merida, Yucatan - Historical Legacy">
                    </div>
                </div>
            </div>
        </section>

        <section id="propiedades" class="seccion bg-alterno">
            <div class="contenedor">
                <h2 data-aos="fade-up">
                    <span class="lang-es">Encuentra la Propiedad de Tus Sueños en Mérida</span>
                    <span class="lang-en">Find Your Dream Property in Merida</span>
                </h2>
                <p class="centrado" data-aos="fade-up" data-aos-delay="100">
                    <span class="lang-es">Ofrecemos una selecta cartera de propiedades que se adaptan a tu estilo de vida y presupuesto. Desde encantadoras casas coloniales en el centro histórico hasta modernas residencias en exclusivos desarrollos.</span>
                    <span class="lang-en">We offer a select portfolio of properties that adapt to your lifestyle and budget. From charming colonial houses in the historic center to modern residences in exclusive developments.</span>
                </p>
                <div class="galeria-propiedades">
                    <div class="tarjeta-propiedad" data-aos="zoom-in">
                        <img src="img/colonial.jpg" alt="Colonial House for Sale">
                        <div class="info-propiedad">
                            <h3>
                                <span class="lang-es">Casa Colonial Restaurada</span>
                                <span class="lang-en">Restored Colonial House</span>
                            </h3>
                            <p class="precio">$6,800,000 MXN</p>
                            <p>
                                <img src="https://img.icons8.com/ios-glyphs/20/000000/bed.png" alt="Bed icon">
                                <span class="lang-es">2 Habitaciones</span><span class="lang-en">2 Bedrooms</span> |
                                <img src="https://img.icons8.com/ios-glyphs/20/000000/shower-and-tub.png" alt="Bathroom icon">
                                <span class="lang-es">2.5 Baños</span><span class="lang-en">2.5 Bathrooms</span>
                            </p>
                            <a href="#contacto" class="btn btn-secundario">
                                <span class="lang-es">Más Detalles</span>
                                <span class="lang-en">More Details</span>
                            </a>
                        </div>
                    </div>
                    <div class="tarjeta-propiedad" data-aos="zoom-in" data-aos-delay="150">
                        <img src="img/casaModerna.jpeg" alt="Modern Residence in North Merida">
                        <div class="info-propiedad">
                            <h3>
                                <span class="lang-es">Residencia Moderna con Alberca</span>
                                <span class="lang-en">Modern Residence with Pool</span>
                            </h3>
                            <p class="precio">$4,250,000 MXN</p>
                            <p>
                                <img src="https://img.icons8.com/ios-glyphs/20/000000/bed.png" alt="Bed icon">
                                <span class="lang-es">3 Habitaciones</span><span class="lang-en">3 Bedrooms</span> |
                                <img src="https://img.icons8.com/ios-glyphs/20/000000/shower-and-tub.png" alt="Bathroom icon">
                                <span class="lang-es">3.5 Baños</span><span class="lang-en">3.5 Bathrooms</span>
                            </p>
                            <a href="#contacto" class="btn btn-secundario">
                                <span class="lang-es">Más Detalles</span>
                                <span class="lang-en">More Details</span>
                            </a>
                        </div>
                    </div>
                    <div class="tarjeta-propiedad" data-aos="zoom-in" data-aos-delay="300">
                        <img src="img/terreno.jpg" alt="Residential Land for Sale">
                        <div class="info-propiedad">
                            <h3>
                                <span class="lang-es">Terreno en zona Exclusiva</span>
                                <span class="lang-en">Land in Exclusive location</span>
                            </h3>
                            <p class="precio">$32,500,000 MXN</p>
                            <p>
                                <span class="lang-es">25,000 m² | Listo para construir</span>
                                <span class="lang-en">25,000 sqm | Ready to build</span>
                            </p>
                            <a href="#contacto" class="btn btn-secundario">
                                <span class="lang-es">Más Detalles</span>
                                <span class="lang-en">More Details</span>
                            </a>
                        </div>
                    </div>
                </div>
                <!--<div class="centrado" style="margin-top: 30px;">-->
                <!--     <a href="#" class="btn btn-primario">-->
                <!--        <span class="lang-es">Ver Todas las Propiedades</span>-->
                <!--        <span class="lang-en">View All Properties</span>-->
                <!--    </a>-->
                <!--</div>-->
            </div>
        </section>

        <section id="contacto" class="seccion">
            <div class="contenedor">
                <h2 data-aos="fade-up">
                    <span class="lang-es">¿Listo para Dar el Siguiente Paso?</span>
                    <span class="lang-en">Ready to Take the Next Step?</span>
                </h2>
                <p class="centrado" data-aos="fade-up" data-aos-delay="100">
                    <span class="lang-es">Contáctanos hoy mismo para una asesoría personalizada. Estamos aquí para ayudarte a encontrar tu lugar ideal en Mérida.</span>
                    <span class="lang-en">Contact us today for personalized advice. We are here to help you find your ideal place in Merida.</span>
                </p>
                <form action="guardar_contacto.php" method="POST" class="formulario-contacto" data-aos="fade-up" data-aos-delay="200">
                    <div class="campo">
                        <label for="nombre">
                            <span class="lang-es">Nombre Completo</span>
                            <span class="lang-en">Full Name</span>
                        </label>
                        <input type="text" id="name" name="name" required>
                    </div>
                    <div class="campo">
                        <label for="email">
                            <span class="lang-es">Correo Electrónico</span>
                            <span class="lang-en">Email Address</span>
                        </label>
                        <input type="email" id="email" name="email" required>
                    </div>
                    <div class="campo">
                        <label for="telefono">
                            <span class="lang-es">Teléfono</span>
                            <span class="lang-en">Phone</span>
                        </label>
                        <input type="tel" id="telefono" name="telefono" required>
                    </div>
                    <div class="campo">
                        <label for="mensaje">
                            <span class="lang-es">Mensaje (opcional)</span>
                            <span class="lang-en">Message  (optional)</span>
                        </label>
                        <textarea id="message" name="message" rows="5"></textarea>
                    </div>
                    <button type="submit" class="btn btn-primario">
                        <span class="lang-es">Enviar Mensaje</span>
                        <span class="lang-en">Send Message</span>
                    </button>
                </form>
            </div>
        </section>
    </main>

    <footer class="footer">
        <div class="contenedor">
            <p>
                <span>2018</span>
                <span class="lang-es">Yucatán World Inmobiliaria - Todos los derechos reservados.</span>
                <span class="lang-en">Yucatán World Real Estate - All rights reserved.</span>
            </p>
            <p>
                <span class="lang-es">Diseñado con ♥ para la mejor ciudad de México.</span>
                <span class="lang-en">Designed with ♥ for the best city in Mexico.</span>
            </p>
        </div>
    </footer>

    <script src="script.js"></script>
    </body>
</html>